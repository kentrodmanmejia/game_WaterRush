var CHECKSUM = {
build: 'f3375a50-ec87-11e6-853a-69675ac00795'
};
module.exports = CHECKSUM;